class Cache {
    constructor() {
      this.user = null;
      this.router = [];
      this.token = null;
      this.tags = null;
      this.email_id = null;
    }
  }
  
  export default new Cache();
  