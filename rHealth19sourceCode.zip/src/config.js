
export const BaseUrl = 'http://13.127.117.78:4000/mobile/'
export const SERVICE_API_URL = 'http://13.127.117.78:4000/mobile/'

