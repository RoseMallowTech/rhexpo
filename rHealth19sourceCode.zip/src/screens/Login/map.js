import React from "react"
import { StyleSheet, Text, View, Dimensions, TouchableOpacity, BackHandler, ToastAndroid, AsyncStorage } from "react-native"
import { MapView } from 'expo';
import { colors } from "../../config/colors";
import { GooglePlacesAutocomplete } from 'react-native-google-places-autocomplete';
import api from "../../api";
import Cache from "../../cache";
import { MaterialIcons } from "@expo/vector-icons";
import { Actions } from "react-native-router-flux";


const width = Dimensions.get('window').width

export default class Map extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      signedIn: false,
      name: "",
      photoUrl: "",
      location: { lat: 19.076090, lng: 72.877426, },
      mapRegion: {
        latitudeDelta:0.4,
        longitudeDelta:0.4
      }
    }
  }


  componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', this.handleBackButton);
  }

  componentWillUnmount() {
      BackHandler.removeEventListener('hardwareBackPress', this.handleBackButton);
  }

  handleBackButton() {
      return true;
  }

   verifyLocation = async () => {

     try {
    const email_ids = await AsyncStorage.getItem('email_id');

    api.updateHomeLocation(email_ids, this.state.location.lat, this.state.location.lng, (err, res) => {

      console.log('*********lat*****', this.state.location.lat)
      console.log('*********long*****', this.state.location.lng)
      console.log('*********email*****', email_ids)

      console.log('*********res*****', res)

      if (err == null) {
        console.log('res', res)
        ToastAndroid.show("Location Updated Successfully", ToastAndroid.SHORT);
        Actions.dashboard()
      } else {
        console.log('err', err)
        ToastAndroid.show("Network request failed", ToastAndroid.SHORT);
      }
    })
  } catch (e) {
    console.log("error", e)

  }
  }
  logoutTest = () => {
    AsyncStorage.removeItem("token");
    AsyncStorage.removeItem("email_id");
    console.log("logoutTest");
  }

  changeRegion(e) {
    console.log("~~~~~Mapview~~~~~", e);
    var loc = {lat:this.state.location.lat, lng:this.state.location.lng}
    loc.lat = parseFloat(e.nativeEvent.coordinate.latitude);
    loc.lng = parseFloat(e.nativeEvent.coordinate.longitude);
    //console.log("Location==================================", loc);

    this.setState({location:loc, mapRegion:this.state.mapRegion});
  }

  changeMarkerRegion(e){
    //console.log("~~~~~marker~~~~~", e);
    var loc = {lat:this.state.location.lat, lng:this.state.location.lng}
    loc.lat = parseFloat(e.nativeEvent.coordinate.latitude);
    loc.lng = parseFloat(e.nativeEvent.coordinate.longitude);
    this.setState({location:loc, mapRegion:this.state.mapRegion});
  }

  zoomChange(region, lat, lon){
    //console.log("zoomChange============================", region)
    var zoomDelta={
      latitudeDelta:region.latitudeDelta,
      longitudeDelta: region.longitudeDelta
    }
    //this.setState({mapRegion:zoomDelta})
    this.state.mapRegion=zoomDelta
  }

  poiClick(e){
    //console.log(e);
    var loc = {lat:this.state.location.lat, lng:this.state.location.lng}
    loc.lat = parseFloat(e.nativeEvent.coordinate.latitude);
    loc.lng = parseFloat(e.nativeEvent.coordinate.longitude);
    this.setState({location:loc, mapRegion:this.state.mapRegion});
  }
  render() {

    // console.log(' * - 1*', this.props.user)
    // console.log(' * - 1*', this.props.user)

    if(this.state.isWaiting){
      return  (
        <View style={styles.container}>
           <Text style={styles.bold}>Loading ...</Text>
        </View>
      )

    }

    return (
      <View style={styles.container}>

        <Text style={styles.header}>{'We need your location to update you on \nthe latest blood groups needed'}</Text>

        <View style={{ marginHorizontal:0,    flex: 1, width: width-24, borderColor:'#DEDEDE', borderWidth:2 }}>
          <MaterialIcons name={"location-on"} size={26} style={{position:'absolute', left:12, zIndex:1, top:7}}/>
          <GooglePlacesAutocomplete
            placeholder='Enter your location.'
            minLength={2} // minimum length of text to search
            autoFocus={false}
            fetchDetails={true}
            onPress={(data, details = null) => { // 'details' is provided when fetchDetails = true
              this.setState({ location: details.geometry.location })
            }}

            query={{
              // available options: https://developers.google.com/places/web-service/autocomplete
              key: 'AIzaSyB1I2oX-x9KEe-qqmW5ZmiB5WzgOuqQc4c',
              language: 'en', // language of the results
              //types: '(cities)', // default: 'geocode'
            }}

            styles={{
              description: {
                fontWeight: 'bold',
                fontSize:12,
                padding:0,
                margin:0,

              },
              predefinedPlacesDescription: {
                color: '#1faadb',
              },
              textInput: {
                width: '100%',
                paddingLeft:30
              },
              textInputContainer: {
                width: '100%',
                backgroundColor: 'rgba(0,0,0,0)',
                borderTopWidth: 0,
                borderBottomWidth: 1,
                borderBottomColor: '#ddd'
              },
            }}
            debounce={200} // debounce the requests in ms. Set to 0 to remove debounce. By default 0ms.

            currentLocation={true} // Will add a 'Current location' button at the top of the predefined places list
            nearbyPlacesAPI='GooglePlacesSearch' // Which API to use: GoogleReverseGeocoding or GooglePlacesSearch
            GoogleReverseGeocodingQuery={{
              // available options for GoogleReverseGeocoding API : https://developers.google.com/maps/documentation/geocoding/intro
            }}


            filterReverseGeocodingByTypes={['locality', 'administrative_area_level_3']} // filter the reverse geocoding results by types - ['locality', 'administrative_area_level_3'] if you want to display only cities

            predefinedPlacesAlwaysVisible={true}
          />
        </View>

        <View style={{ height: width / 1.2, width: width - 24, marginTop: 10, borderColor:'#DEDEDE', borderWidth:2 }}>

          <MapView
            style={{ flex: 1 }}
            showsIndoorLevelPicker={true}
            onRegionChangeComplete={this.reloadEntities}
            initialRegion={{
              latitude: this.state.location.lat,
              longitude: this.state.location.lng,
              latitudeDelta: this.state.mapRegion.latitudeDelta,
              longitudeDelta: this.state.mapRegion.longitudeDelta,
            }}
            region={{
              latitude: this.state.location.lat,
              longitude: this.state.location.lng,
              latitudeDelta: this.state.mapRegion.latitudeDelta,
              longitudeDelta: this.state.mapRegion.longitudeDelta,
            }}
            showsUserLocation={true}
            showsCompass={false}
            loadingEnabled={true}
            onPress={e => {this.changeRegion(e)}}
            onRegionChange={(region, lat, lon) => {this.zoomChange(region, lat, lon)}}
            onPoiClick={(e)=>{this.poiClick(e)}}
            //onMarkerPress= {e => {this.changeMarkerRegion(e)}}
            //onCalloutPress
          >

            <MapView.Marker
              key={1}
              coordinate={{
                latitude: parseFloat(this.state.location.lat),
                longitude: parseFloat(this.state.location.lng),
              }}
              //onCalloutPress={e => {this.changeMarkerRegion(e)}}
              // onPress={e => {this.changeMarkerRegion(e)}}
            // image={require('../../../assets/images/mark.png')}
            >

            </MapView.Marker>

          </MapView>
        </View>

        <View style={{ width: '100%' }}>
          <TouchableOpacity style={styles.btn} onPress={this.verifyLocation}>
            <Text style={styles.txt}>Set Home Location</Text>
          </TouchableOpacity>
        </View>

      </View>

    )
  }
}


const styles = StyleSheet.create({
  container: {
    flex: 1,

    paddingTop: width / 10,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center"
  },
  header: {
    fontSize: 16,
    marginTop: 12,
  },
  image: {
    marginTop: 15,
    width: 60,
    height: 60,
    borderColor: "rgba(0,0,0,0.2)",
    borderWidth: 3,
    borderRadius: 30
  },
  btn: {
    backgroundColor: colors.BLUE,
    borderRadius: 30,
    marginHorizontal: width / 10,
    marginVertical:12,
    padding: 17,
    justifyContent: 'center',
    alignItems: 'center'
  },
  txt: {
    fontSize: 16,
    color: colors.WHITE
  },
  input: {
    borderBottomColor: '#222',
    borderBottomWidth: 1,
    fontSize: 20,
    paddingLeft: 36,
    paddingVertical: 5,
    width: '100%',
  }
})
