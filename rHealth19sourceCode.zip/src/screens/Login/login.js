import React from "react"
import { StyleSheet, Text, View, Image, Dimensions, TouchableOpacity, AsyncStorage, ToastAndroid } from "react-native"
import { Google } from 'expo';
import { Actions } from "react-native-router-flux";
import { images } from "../../config/images";
import { colors } from "../../config/colors";
import Cache from "../../cache";
import api from "../../api";

const width = Dimensions.get('window').width

export default class Login extends React.Component {

  constructor(props) {
    super(props)
    this.state = {
      signedIn: false,
      name: "",
      photoUrl: "",
      language: { latitude: 12.5937, longitude: 63.9629, },
      isWaiting:false,
    }
  }

  signIn = async () => {
    this.setState({isWaiting:true})
    try {
      const result = await Google.logInAsync({
        androidClientId:
          "933764359119-m9830q14acgumrvfjkh7uc4dn9v8qrf1.apps.googleusercontent.com",
        iosClientId: "603386649315-vp4revvrcgrcjme51ebuhbkbspl048l9.apps.googleusercontent.com",
        scopes: ["profile", "email"]
      })


      if (result.type === "success") {
        // console.log('my success token!!!', result.accessToken)
        console.log('*********first*****', result.user.familyName)
        console.log('*********last*****', result.user.givenName)
        console.log('*********email*****', result.user.email)


        AsyncStorage.setItem('token', result.accessToken);
        AsyncStorage.setItem('email_id', result.user.email);


        // await AsyncStorage.setItem('user', {
        //   user: result.user.name,
        //   photoUrl: result.user.photoUrl
        // });


        api.checkAndAddUser(result.user.email, result.user.familyName, result.user.givenName, (err, res) => {
          console.log('Loading api results..')

        if (err == null) {
          console.log('Response', res)
          ToastAndroid.show(res.type, ToastAndroid.SHORT);
          if(res.type == 'EXISTING')
          {
          Actions.dashboard()
          }
          else {
            Actions.otp()
          }
          this.setState({isWaiting:false})
        } else {
          console.log('Error code', err)

          // ToastAndroid.show('Found existing user', ToastAndroid.SHORT);
          this.setState({isWaiting:false})
          Actions.otp()
        }
        this.setState({ isWaiting: false })
      })



        // Actions.map({ user: result.user.name, photoUrl: result.user.photoUrl });

      } else {
        console.log("cancelled")
        this.setState({isWaiting:false})
      }
    } catch (e) {
      console.log("error", e)
      this.setState({isWaiting:false})
    }
  }

  render() {

    if(this.state.isWaiting){
      return  (
        <View style={styles.container}>
           <Text style={styles.bold}>Loading ...</Text>
        </View>
      )

    }
    return (
      <View style={styles.container}>

        <View style={{ justifyContent: 'center', alignItems: 'center' }}>

          <Image source={images.logo} style={styles.logo} />

          <View>

            <View style={{ flexDirection: 'row', marginVertical: width/10, }}>
              <TouchableOpacity>
                <Image source={images.btn_facebook} style={{ width: width / 2.3, height: width / 7 }} />
              </TouchableOpacity>

              <TouchableOpacity onPress={this.signIn} >
                <Image source={images.btn_google} style={{ width: width / 2.3, height: width / 7 }} />
              </TouchableOpacity>
            </View>

            <Text style={styles.normal}>Or Continue with </Text>


            <TouchableOpacity style={styles.btn}>
              <Text style={styles.txt}>Sign in with Email</Text>
            </TouchableOpacity>

          </View>

        </View>
      </View>
    )
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center"
  },
  logo: {
    width: width / 1.7,
    height: width / 1.5,
    marginVertical:width/10
  },
  btn: {
    backgroundColor: colors.BLUE,
    borderRadius: 30,
    margin: width / 10,
    padding:17,
    justifyContent:'center',
    alignItems:'center'
  },
  txt:{
    fontSize: 16,
    color:colors.WHITE
  },
  bold:{
    fontWeight:'bold',
    textAlign:'center',
    fontSize:17
  },
  normal:{
    fontWeight:'300',
    textAlign:'center',
    fontSize:17
  }

})
