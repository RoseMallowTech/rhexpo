import React, { Component } from 'react';
import { Text, View, Image ,AsyncStorage } from 'react-native';
import { images } from "../../config/images";

export default class Dashboard extends Component {

  constructor(props) {
    super(props);

    this.state = {
      username: ''
    };
    this.loadusername();
  }

  async loadusername(){

const email_ids = await AsyncStorage.getItem('email_id');
this.setState({username:email_ids})

  }

  render() {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>

        <Text>{this.state.username}</Text>
        <Image source={images.logo} style={{width:'50%',height:'50%',resizeMode:'contain'}} />
      </View>
    );
  }
}
