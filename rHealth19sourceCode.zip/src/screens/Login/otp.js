import React, { Component } from 'react';
import { Alert, Button, TextInput, View, StyleSheet, BackHandler, Image, Text, TouchableOpacity, KeyboardAvoidingView, Dimensions, ToastAndroid, AsyncStorage, StatusBar } from 'react-native';
import { Actions } from "react-native-router-flux";
import { images } from '../../config/images';
import api from "../../api";
import Cache from "../../cache";
import {colors} from '../../config/colors'
const width = Dimensions.get('window').width




export default class Otpverifypage extends Component {
  constructor(props) {
    super(props);

    this.state = {
      username: '',
      password: '',
      sessionid: '',
      optBoolean: false,
      isWaiting:false,
      disabled:true
    };
  }

  componentDidMount() {
    BackHandler.addEventListener('hardwareBackPress', this.handleBackButton);
  }

  componentWillUnmount() {
      BackHandler.removeEventListener('hardwareBackPress', this.handleBackButton);
  }

  handleBackButton() {
      return true;
  }



  onLogin() {
    const { username, password, sessionid } = this.state;
    var value = '';

    fetch("http:myapi.com/")
      .then((response) => response)
      .then((responseData) => {
        value = responseData._bodyText;
        console.log(responseData._bodyText); //prints what I want
      })
      .done();

    console.log(value);

    fetch('https://2factor.in/API/V1/44dc007c-4205-11e9-8806-0200cd936042/SMS/+91' + username + '/AUTOGEN', {
      method: 'get',
      dataType: 'jsonp',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    })
      .then((response) => {
        return response.json() // << This is the problem
      })
      .then((responseData) => { // responseData = undefined
        // addTestToPage(responseData.title);
        //Alert.alert('Credentials', `${username} + ${password}`);
        //Alert.alert('Response', `${responseData.Status} + ${responseData.Details}`);

        this.setState({ sessionid: responseData.Details });

        if (responseData.Status == "Success") {
          ToastAndroid.show('OTP Sent Successfully', ToastAndroid.SHORT);
          this.setState({ optBoolean: true })
        this.setState({ disabled: false })
        } else {
          this.setState({ optBoolean: false })
          this.setState({ disabled: true })
        }

        return responseData;
      })
      .catch(function (err) {
        console.log(err);
      })
  }


  onSubmit = async () => {



    const { username, password, sessionid } = this.state;
    var value = '';

    fetch("http:myapi.com/")
      .then((response) => response)
      .then((responseData) => {
        value = responseData._bodyText;
        console.log(responseData._bodyText); //prints what I want
      })
      .done();

    // console.log(value);

    fetch('https://2factor.in/API/V1/44dc007c-4205-11e9-8806-0200cd936042/SMS/VERIFY/' + this.state.sessionid + '/' + password, {
      method: 'get',
      dataType: 'jsonp',
      headers: {
        'Accept': 'application/json',
        'Content-Type': 'application/json'
      }
    })
      .then((response) => {
        console.log('my 1', response)
        return response.json() // << This is the problem

      })
      .then(async (responseData) => { // responseData = undefined
        console.log('my 2', responseData)

        // addTestToPage(responseData.title);
        //Alert.alert('Credentials', `${username} + ${password}`);
      //  Alert.alert('Response', `${responseData.Status} + ${responseData.Details}`);

        if (responseData.Status !== "Error") {
          this.setState({isWaiting:true})
          const email_ids = await AsyncStorage.getItem('email_id');


          api.updatePhoneNumber (this.state.username, email_ids, "GOOGLE", async (err, res) => {

            console.log('*********phone_no*****', this.state.username)
            console.log('*********email_id*****', email_ids)

            await AsyncStorage.setItem('otp', "You are verified with your phonenumber");

            if (err == null) {

              console.log('Response', res)

              if(res.err == '0')
              {
                console.log('sucessssssss', res.err)
              Actions.map()
              }
              else {

              }


              this.setState({isWaiting:false})

              // ToastAndroid.show('Successfully updated!', ToastAndroid.SHORT);
            } else {
              console.log('Error Code', err)
              // ToastAndroid.show('Fail Save Data !', ToastAndroid.SHORT);
              this.setState({isWaiting:false})

            }
          })
          ToastAndroid.show('OTP Matched Successfully', ToastAndroid.SHORT);
        } else {
          this.setState({isWaiting:false})

          ToastAndroid.show('OTP Mismatch', ToastAndroid.SHORT);
        }
        return responseData;
      })
      .catch(function (err) {
        console.log(err);
      })
  }

  render() {

    if(this.state.isWaiting){
      return  (
        <View style={[styles.container, {alignItems:'center'}]}>
           <Text style={styles.bold}>Loading ...</Text>
        </View>
      )

    }

    return (
      <KeyboardAvoidingView style={styles.container_ico} behavior="padding" enabled>
        <View style={{flex:1, justifyContent:"space-evenly"}}>

          <Image source={images.smsicon}
            style={{ marginBottom:'7%', height:'20%', width:'100%', flexDirection:'row', resizeMode:'contain', alignItems:'center'}} />


          <View>
            <TouchableOpacity style={{ alignSelf: 'flex-start', height: 44, position:"absolute", padding:0, right:0, marginTop: 0, justifyContent:'center'}} activeOpacity={0.5} onPress={this.onLogin.bind(this)}>
              <Text style={{ color: '#00a0dd', fontWeight: 'bold', fontSize: 16, marginLeft:10, paddingRight: 20, textAlign:'right' }}>Get OTP</Text>
            </TouchableOpacity>
            <TextInput
                keyboardType='numeric'
                value={this.state.username}
                onChangeText={(username) => this.setState({ username })}
                placeholder={'Phone Number'}
                placeholderTextColor="#888"
                style={styles.inputPhoneNumber}
                maxLength={10}
              />
              {this.state.optBoolean &&
                <View style={{ marginTop: '10%' }} >
                  <TextInput
                    hidden={this.state.optBoolean ? true : false}
                    value={this.state.password}
                    onChangeText={(password) => this.setState({ password })}
                    placeholder={'Enter OTP'}
                    placeholderTextColor="#888"
                    style={styles.inputPhoneNumber}
                    maxLength={6}
                  />
                </View>
              }
          </View>


            <View style={{marginTop:'7%'}}>
              <TouchableOpacity  disabled={this.state.disabled} activeOpacity={0.5} onPress={this.onSubmit.bind(this)} >
                <View style={[styles.btnverify, { backgroundColor: this.state.disabled ? '#607D8B' : '#00a0dd' }]}>
                  <Text style={styles.txtverify}>Verify Phone</Text>
                </View>
              </TouchableOpacity>
            </View>


        </View>
      </KeyboardAvoidingView>
    );
  }
}

const styles = StyleSheet.create({
  container_ico: {
    flex: 1,
    margin:10,
    marginTop: StatusBar.currentHeight+10,
    backgroundColor: '#f7f7f7'
  },
  container: {
    flex: 1,
    justifyContent: 'center',
    margin: 10,
    backgroundColor: '#f7f7f7'

  },
  inputPhoneNumber: {
    paddingVertical: 0,
    paddingLeft: 10,
    paddingRight: 20,
    marginLeft:20,
    marginRight:20,
    zIndex: -1,
    width: width - 60,
    height: 44,
    fontSize: 20,
    borderBottomColor: '#888',
    borderBottomWidth: 1
  },

  inputinputOTP: {
    paddingVertical: 0,
    paddingLeft: 20,
    paddingRight: 20,
    zIndex: -1,
    width: width - 20,
    height: 44,
    fontSize: 20,
    borderBottomColor: '#888',
    borderBottomWidth: 1
  },

  imageinput: {
    width: 360,
    height: 250,
    padding: 10,
    borderWidth: 1,
    marginBottom: 10,
  },

  btninput: {
    width: 300,
    height: 50,
    padding: 10,
    borderWidth: 1,
    marginBottom: 10,
    marginLeft: 20,
    marginTop: 40
  },

  txtinput: {
    width: 320,
    height: 44,
    padding: 20,
    marginBottom: 10,
    marginLeft: 20,
    fontSize: 15,
    marginTop: 20
  },
  btnverify:{
    borderRadius: 30,
    marginHorizontal: width / 10,
    paddingVertical: 17,
    justifyContent: 'center',
    alignItems: 'center'
  },
  txtverify:{
    fontSize: 16,
    color: colors.WHITE ,
  }
});
