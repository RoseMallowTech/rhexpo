import React, { PureComponent } from 'react'

import { KeyboardAvoidingView, Platform, AsyncStorage } from 'react-native'
import { Scene, Router } from 'react-native-router-flux'
import { Font } from 'expo'

import Login from './screens/Login/login';
import Map from './screens/Login/map';
import OTP from './screens/Login/otp';
import DASHBOARD from './screens/Login/dashboard';

export default class  App extends PureComponent {

  state = {
    fontLoaded: false,
    initial: false,
    otp_boolean: false,
    map_boolean: false
  };

  async componentDidMount() {
    await this._loadAssets();
    this._retrieveData()

  }

  _retrieveData = async () => {
    try {
      const token = await AsyncStorage.getItem('token');
      const otp = await AsyncStorage.getItem('otp');

      if (token !== null) {
        // We have data!!
        console.log('token ---------', token);
        console.log('otp ---------', otp);

        if(otp !== null){
          this.setState({ map_boolean: true })
        } else {

        }

        this.setState({initial:true, otp_boolean: true})
      } else {
        this.setState({initial:true})
        console.log('token no');

      }
    } catch (error) {
      // Error retrieving data
      console.log('eeeeeeeeee', error);
      this.setState({initial:true})
    }
  };

  async _loadAssets() {
    await Font.loadAsync({

      'Montserrat-Light': require('../assets/fonts/Montserrat-Light.ttf'),
      'material-community': require('../assets/fonts/Montserrat-Light.ttf'),
      'material': require('../assets/fonts/Montserrat-Light.ttf'),


    });
    console.log('fonts loaded!');
    this.setState({ fontLoaded: true });
  }
  render() {

    return (
      <KeyboardAvoidingView
        behavior={Platform.OS === 'ios' ? 'padding' : null}
        style={{ flex: 1 }}>
        {this.state.fontLoaded == true && this.state.initial == true?

          <Router>
            <Scene>
              <Scene key="login" component={Login} initial={false} hideNavBar/>
              <Scene key="otp" component={OTP} initial={false} hideNavBar/>
              <Scene key="map" component={Map} initial={this.state.map_boolean} hideNavBar/>
              <Scene key="dashboard" component={DASHBOARD} initial={this.state.otp_boolean} hideNavBar/>

            </Scene>
          </Router>
          : null}
      </KeyboardAvoidingView>
    );
  }
}
