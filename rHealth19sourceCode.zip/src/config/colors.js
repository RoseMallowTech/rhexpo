export const colors = {

    BLUE: '#2ca9d7',
    WHITE: '#fff',
    DARK: '#000',

  }