export const images = {

    btn_facebook: require('../../assets/images/facebook.png'),
    btn_google: require('../../assets/images/google.png'),
    logo: require('../../assets/images/logo.png'),

    smsicon: require('../../assets/images/smsicon.png'),
    verifyphone: require('../../assets/images/verifyphone.png'),

    
    
};
