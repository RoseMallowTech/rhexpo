import React, { PureComponent } from 'react';
import Router from './src/router';

export default class Driver extends PureComponent {
  render() {
    return (
        <Router />
    );
  }
}